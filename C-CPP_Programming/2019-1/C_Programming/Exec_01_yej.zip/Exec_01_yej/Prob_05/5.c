﻿#include <stdio.h>
int main()
{
	
	char i = 127;
	i++;
	printf("%d\n", i);
	i++;
	printf("%d\n", i);
	i++;
	printf("%d\n", i);
	i= -127;
	i--;
	printf("%d\n", i);
	i--;
	printf("%d\n", i);
	i--;
	printf("%d\n", i);


	return 0;
	//i가 가질 수 있는 최솟값은 -128이다.
	//i 값이 127 이상이 될 때 실제로 연산 결과로 저장되는 i 값은 얼마인가? -128
}
