
#include <stdio.h>
int main()
{

	float C, F;
	scanf("%f", &F);
	C = (5.0 / 9.0)*(F - 32);
	printf("%f", C);
	return 0;

}
