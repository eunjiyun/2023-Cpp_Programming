#include <stdio.h>
int main()
{
	
	int mile;
	double meter;
	scanf("%d", &mile);
	meter = 1609 * mile;
	printf("%lf", meter);

	return 0;

}
