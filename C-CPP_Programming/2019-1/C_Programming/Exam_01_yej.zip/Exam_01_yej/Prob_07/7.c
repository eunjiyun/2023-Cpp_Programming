#include<stdio.h>
int main()
{
	int a, b,i;
	printf("while���� �̿��� ����\n");
	a = 0;
	b = 0;
	i= 1;
	while (i <= 100000)
	{
		
		if (i % 2 != 0 && i % 3 != 0 && i % 5 != 0 && i % 7 != 0)
		{
			a = i;
		}
		b = b + a;
		i++;

	}
	printf("%d\n\n", b);

	printf("do~while���� �̿��� ����\n");
	a = 0;
	b = 0;
	i = 1;
	do
	{
		if (i % 2 != 0 && i % 3 != 0 && i % 5 != 0 && i % 7 != 0)
		{
			a = i;
		}
		b = b + a;
		i++;
	} while (i <= 100000);
	printf("%d\n\n", b);

	printf("for���� �̿��� ����\n");
	a = 0;
	b = 0;
	for (i = 1; i <= 100000; i++)
	{
		if (i % 2 != 0 && i % 3 != 0 && i % 5 != 0 && i % 7 != 0)
		{
			a = i;
		}
		b = b + a;

	}
	printf("%d", b);

	return 0;
}