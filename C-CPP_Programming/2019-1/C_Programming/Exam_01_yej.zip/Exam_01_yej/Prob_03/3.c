#include<stdio.h>
int main()
{
	int a, b, c,d,e;
	scanf("%d", &a);
	if (a <= 20)
		printf("1500��");
	else if (a >= 21 && a <= 40)
	{
		b = (a - 20) * 100 + 1500;
		printf("%d", b);
	}
	else if (a >= 41 && a <= 80)
	{
		c = 2000 + 1500 + (a - 40) * 150;
		printf("%d", c);
	}

	else if (a >= 81 && a <= 150)
	{
		d = 1500 + 2000 + 150 * 40 + (a - 80) * 200;
		printf("%d", d);
	}
	else
	{
		e = 1500 + 2000 + 150 * 40 + 200 * 70 + (a - 150) * 300;
		printf("%d", e);
	}
	return 0;
}