#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int random()
{
	static init = 0;

	if (init == 0) {
		printf("** �ʱ�ȭ ***\n");
		srand((unsigned int)time(NULL));
		init = 1;
	}
	return (rand() % 6) + 1;
}

int main(void)
{

	int i;

	for (i = 0; i < 100; i++)
		printf("%d \n", random());

	return 0;
}