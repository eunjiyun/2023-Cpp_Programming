#include <stdio.h>
extern int x;

int f_2()
{
	printf("%d\n", x);
	return x + 1;
}