#include <stdio.h>

	int f_1(int);
	extern int f_2();

	int x = 100;

	int f_1(int x)
	{
		printf("%d\n", x);
		return x + 1;
	}

	int main(void)
	{
		int x = 10;

		printf("%d \n", x);
		{
			int x = 20;
			printf("%d\n", x);
			x = f_1(x);
			printf("%d\n", x);
		}
		printf("%d\n", x);
		x = f_2();
		printf("%d\n", x);
	return 0;
}