#include <stdio.h>
double f_abs(double a);
double f_min(double x, double y);
int f_equal(double x, double y);
int main()
{
	double x,y;
	printf("�Ǽ��� �Է��ϼ���");
		scanf(" %lf", &x);
		printf("�Ǽ��� �Է��ϼ���");
		scanf(" %lf", &y);
		
		if (f_equal(x, y) == 1)
			printf("����");
		else if (f_equal(x, y) == 0)
			printf("�ٸ�");
	return 0;
}
double f_abs(double a)
{
	if (a >= 0)
		return a;
	else
		return -a;
}
double f_min(double x, double y)
{
	if (x >= y)
		return y;
	else
		return x;
}
int f_equal(double x, double y)
{
	double a,e;
	 a= x - y;
	 e = 0.0001;
	 if ( f_abs(a) /  f_min(x, y) < e)
		 return 1;
	 else
		 return 0;
}