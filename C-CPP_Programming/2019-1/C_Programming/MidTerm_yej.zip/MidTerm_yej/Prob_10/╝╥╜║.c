#include <stdio.h>
static int a, b;
int rec_fib(int n)
{
	if (n == 0)
		return a;
	else if (n == 1)
		return b;
	else if (n == 2)
		return a + b;
	else
		return rec_fib(n - 1) + rec_fib(n - 2);
}
int itr_fib(int n)
{
	int re,i;
	for (i = 1; i < n; i++)
	{
		re = a + b;
		a = b;
		b = re;
	}
	return re;
}
int main()
{
	scanf("%d %d", &a, &b);
	
}