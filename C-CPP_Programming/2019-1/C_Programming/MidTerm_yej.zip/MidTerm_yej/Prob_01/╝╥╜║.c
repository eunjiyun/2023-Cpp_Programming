#include <stdio.h>
int main()
{
	printf("char:%d  short:%d  int :%d  long:%d   long long: %d  float:%d  double:%d  long double : %d  ", sizeof(char), sizeof(short), sizeof(int), sizeof(long), sizeof(long long), sizeof(float), sizeof(double), sizeof(long double));
	return 0;
}