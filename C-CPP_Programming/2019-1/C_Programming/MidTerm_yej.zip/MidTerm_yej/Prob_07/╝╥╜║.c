#include <stdio.h>
char conv_char(char n);

int main()
{
	 
	for (;;)
	{
		char c;
		
			printf("���� �Է�");
			scanf(" %c", &c);
			conv_char(c);
			if (conv_char(c) != 0)
		{
			printf("�Է��� ���� %c�� %c�� ��ȯ��\n", c, conv_char(c));
		}
		else
			break;
	}
	return 0;
}
char conv_char(char n)
{
	if (n >= 65 && n <= 90)
		return n + 32;
	else if (n >= 97 && n <= 122)
		return n - 32;
	else
		return 0;
	
}