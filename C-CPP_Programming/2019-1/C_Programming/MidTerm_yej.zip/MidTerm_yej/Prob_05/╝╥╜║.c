#include <stdio.h>
int main()
{
	int i, j;
	printf("2��          3��          4��         5��           6��           7��          8��          9�� \n");
	for (i = 1; i <= 9; i++)
	{
		for (j = 2; j <= 9; j++)
		{
			printf("%dx%d=%d       ", j, i, j*i);
			if (j == 9)
				printf("\n");
		}
	}
	return 0;
}