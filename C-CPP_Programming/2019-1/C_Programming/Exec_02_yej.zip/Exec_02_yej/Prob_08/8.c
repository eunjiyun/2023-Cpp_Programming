#include <stdio.h>	
int main()
{
	int t,num1;
	t = 1000;
	num1 = (12 * t - 40 * 20)/40;
	printf("%d", num1);

	return 0;
}