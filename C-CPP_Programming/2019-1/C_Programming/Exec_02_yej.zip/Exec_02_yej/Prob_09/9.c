#include <stdio.h>	
int main()
{
	float num1 = 1.0e38*100;
	float num2 = 1.0e-37/1000;
	printf("%f\n%lf", num1, num2);
	return 0;
}