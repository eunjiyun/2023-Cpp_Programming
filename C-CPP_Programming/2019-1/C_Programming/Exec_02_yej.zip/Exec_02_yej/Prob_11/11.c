#include <stdio.h>
int main()
{
	int b = 7;
	char a = '7';
	char str[2]="7";
	printf("%d %c %s", b, a, str);
	return 0;
}
