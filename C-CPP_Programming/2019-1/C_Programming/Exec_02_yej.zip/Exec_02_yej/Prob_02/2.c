#include <stdio.h>
#include <limits.h>
#include <float.h>
int main()
{
	
	int a = INT_MAX;
	double b = DBL_MAX;
	printf("char:%d\n", CHAR_MAX);
	printf("short:%d\n", SHRT_MAX);
	printf("int:%d\n", INT_MAX);
	printf("long:%ld\nlong long:%lld\nfloat:%f\ndouble:%f\n", LONG_MAX, LLONG_MAX, FLT_MAX, DBL_MAX);
	printf("long double:%lf\n", LDBL_MAX);
	printf("int max:%d, ", INT_MAX);
	printf("int max+1:%d\n", a + 1);
	printf("double max:%f, ", DBL_MAX);
	printf("doble max+1:%lf", b + 1);

		


	
	return 0;
}