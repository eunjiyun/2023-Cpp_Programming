#include <stdio.h>
#include <math.h>
int main()
{
	double a, b, c;
	a = 10;
	b = pow(1.002, 24.0*365.0);
	c = a * b;
	printf("%lf", c);

	return 0;
}