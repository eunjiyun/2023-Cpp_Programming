#include <stdio.h>
int main()
{

	printf("while����\n");
	int i;
	i = 0;

	while (i < 100)
	{
		if (i == 10 || i == 20 || i == 30 || i == 40 || i == 50 || i == 60 || i == 70 || i == 80 || i == 90)
			printf("\n");
		else
			printf("");

		if (i == 0 || i == 10 || i == 20 || i == 30 || i == 40 || i == 50 || i == 60 || i == 70 || i == 80||i==90)
			printf(" ");
		else
			printf("");


		if (i % 3 == 0 || i % 10 == 3 || i % 10 == 6 || i % 10 == 9)
		{

			printf("*  ");

		}
		else
		{
			if (i < 10)
				printf(" %d ", i);
			else
				printf("%d ", i);
		}
		i++;
	}
	printf("\ndo while����\n");
	i = 0;
	do
	{

		if (i == 10 || i == 20 || i == 30 || i == 40 || i == 50 || i == 60 || i == 70 || i == 80 || i == 90)
			printf("\n");
		else
			printf("");
		if (i == 0 || i == 10 || i == 20 || i == 30 || i == 40 || i == 50 || i == 60 || i == 70 || i == 80 || i == 90)
			printf(" ");
		else
			printf("");
		if (i % 3 == 0 || i % 10 == 3 || i % 10 == 6 || i % 10 == 9)
		{

			printf("*  ");

		}
		else
		{
			if (i < 10)
				printf(" %d ", i);
			else
				printf("%d ", i);
		}
		i++;
	} while (i < 100);
	printf("\nfor����\n");
	for (i = 0; i < 100; i++)
	{
		if (i == 10 || i == 20 || i == 30 || i == 40 || i == 50 || i == 60 || i == 70 || i == 80 || i == 90)
			printf("\n");
		else
			printf("");
		if (i == 0 || i == 10 || i == 20 || i == 30 || i == 40 || i == 50 || i == 60 || i == 70 || i == 80 || i == 90)
			printf(" ");
		else
			printf("");
		if (i % 3 == 0 || i % 10 == 3 || i % 10 == 6 || i % 10 == 9)
		{

			printf("*  ");

		}
		else
		{
			if (i < 10)
				printf(" %d ", i);
			else
				printf("%d ", i);
		}

	}

	return 0;
}