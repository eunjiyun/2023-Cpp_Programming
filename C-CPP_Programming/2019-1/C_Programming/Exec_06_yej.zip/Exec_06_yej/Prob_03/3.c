#include <stdio.h>
int main()
{
	int i;
	printf("%d %d %d %d ", 2, 3, 5, 7);
	for (i = 2; i <= 100; i++)
	{
		if (i % 2 == 0)
		{
			printf("");

		}
		else if (i % 3 == 0)
		{
			printf("");

		}
		else if (i % 5 == 0)
		{
			printf("");

		}
		else if (i % 7 == 0)
		{
			printf("");

		}
		else
			printf("%d ", i);

	}
	return 0;
}