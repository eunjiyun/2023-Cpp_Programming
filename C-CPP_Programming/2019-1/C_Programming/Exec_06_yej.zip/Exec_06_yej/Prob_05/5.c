#include <stdio.h>
int main()
{
	int x, y, z,n;
	n = 81;
	
	
	

	for (x = 1; x <= 10; x++)
	{
		for (y = 1; y <= 10; y++)
		{
			for (z = 1; z <= 10; z++)
			{
				if (n == 2 * x + 3 * y + 5 * z)
					printf("2g:%d�� 3g:%d�� 5g:%d��\n", x, y, z);
				else
					printf("");
			}
			
		}

	}

	return 0;
}
