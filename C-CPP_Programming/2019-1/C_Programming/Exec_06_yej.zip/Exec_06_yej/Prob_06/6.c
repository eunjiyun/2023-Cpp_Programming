#include <stdio.h>
int main()
{
	int a, i,b,c;


	printf("2�̻� ū �� �Է�: ");

	scanf("%d", &a);
	c = a;
	printf("%d= ", a);
	for (i = 0; i < c; i++)
	{

		if (a % 2 == 0)
		{
			if (a == 2)
			{
				printf("%d", 2);
				break;
			}
			else
			{
				b = 2;
				a = a / 2;
			}
		}
		else if (a % 3 == 0)
		{
			if (a == 3)
			{
				printf("%d", 3);
				break;
			}
			else
			{
				b = 3;
				a = a / 3;
			}
		}
		else if (a % 5 == 0)
		{
			if (a == 5)
			{
				printf("%d", 5);
				break;
			}
			else
			{
				b = 5;
				a = a / 5;
			}
		}
		else if (a % 7 == 0)
		{
			if (a == 7)
			{
				printf("%d", 7);
				break;
			}
			else
			{
				b = 7;
				a = a / 7;
			}
		}
		else
		{
			a = a;
			printf("%d ", a);
			break;

		}
		printf("%d ", b);
	}

	return 0;
}
