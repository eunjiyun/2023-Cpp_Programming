#include <stdio.h>
int main()
{
	int i, b, c,a,d,e,f,g;
	
	printf("��� ���� �� �Է�: ");
	scanf("%d", &a);
	
	for (i = 0; i < a / 2; i++)
	{

		for (c = 0; c < i; c++)
		{
			printf(" ");
		}
		printf("*");
		for (b = 0; b < a - i * 2 - 2; b++)
		{
			printf(" ");
		}
		printf("*\n");
	}
	if (a % 2 != 0)
	{
		for (g = 0; g < a / 2; g++)
		{
			printf(" ");
		}
		printf("*\n");
		for (d = 0; d < a  / 2; d++)
		{
			for (e = (a/2-1 )- d; e > 0; e--)
			{
				printf(" ");
			}
			printf("*");
			for (f = 0; f < a - ((a / 2 - 1) - d) * 2 - 2; f++)
			{
				printf(" ");
			}
			printf("*\n");
		}
	}
	else

		for (d =0; d<a / 2;  d++)
		{
			for (e = (a / 2 - 1) -d; e >0; e--)
			{
				printf(" ");
			}
			printf("*");
			for (f = 0; f <a-((a / 2 - 1) -d)*2-2 ; f++)
			{
				printf(" ");
			}
			printf("*\n");
		}
		
	
	return 0;
}