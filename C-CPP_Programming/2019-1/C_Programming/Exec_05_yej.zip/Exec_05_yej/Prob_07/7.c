#include <stdio.h>
int main()
{
	int a, b, c, d, e,f;
	a <= 1000000;
	scanf("%d", &a);
	b = a / 10000;
	c = a % 10000 / 1000;
	d = a % 10000 % 1000 / 100;
	e= a % 10000 % 1000 % 100 / 10;
	f = a % 10000 % 1000 % 100 % 10;
	if (b > 0)
		printf("%d��", b);
		
	else
		printf("");
	if (c > 0)
		printf("%dõ", c);
	else
		printf("");
	if (d > 0)
		printf("%d��", d);
	else
		printf("");
	if (e > 0)
		printf("%d��",e);
	else
		printf("");
	if (f> 0)
		printf("%d", f);
	else
		printf("");

	
	return 0;
}