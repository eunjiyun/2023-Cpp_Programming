#include <stdio.h>
int main()
{
	

	int x, y,z;


	scanf("%x %x", &x, &y);
	x = x >> 16;
	x = x <<16;
	y = y << 16;
	y = y >> 16;

	z = x | y;

	printf("%#x", z);

	return 0;
}