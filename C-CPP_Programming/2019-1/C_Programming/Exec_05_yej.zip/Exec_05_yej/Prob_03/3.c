#include <stdio.h>
int main()
{
	float mon1,mon2;
	int mon3;
	printf("���� ǥ�ؾ��� �Է��ϼ���.");
	scanf("%f", &mon1);
	if (mon1 <= 12000000)
	{
		mon3 = 6;
		mon2 = mon1 * 0.06;
	}
	
	else if (mon1 > 12000000 && mon1 <= 46000000)
	{
		mon3 = 15;
		mon2 = 720000 + (mon1 - 12000000)*0.15;
	}
	else if (mon1 > 46000000 && mon1 <= 88000000)
	{
		mon3 = 24;
		mon2 = 5820000 + (mon1 - 46000000)*0.24;
	}
	else if (mon1 > 88000000 && mon1 <=300000000)
	{
		mon3 = 35;
		mon2 = 15900000 + (mon1 - 88000000)*0.35;
	}
	else if (mon1 > 300000000)
	{
		mon3 = 38;
		mon2 = 90100000 + (mon1 - 300000000)*0.38;
	}
		printf("�ְ�����:%d%%  ����:%f", mon3, mon2);
	
	return 0;
}