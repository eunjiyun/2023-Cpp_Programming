#include <stdio.h>

int main()
{
	
	int x, y, z, max, min;
	

	scanf("%d %d %d", &x, &y, &z);
	if (x > y)
	{
		if (x > z)
			max = x;
		else
			max = z;
	}
	else
	{
		if (y > z)
			max = y;
		else
			max = z;
	}
	min = (x < y) ? ((x < z) ? x : z) : ((y < z) ? y : z);
	
	
	
	printf("�ִ밪:%d �ּҰ�:%d", max, min);
	
	return 0;
}