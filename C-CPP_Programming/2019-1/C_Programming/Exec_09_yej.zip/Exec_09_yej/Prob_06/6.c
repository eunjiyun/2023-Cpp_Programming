#include <stdio.h>

int main()
{
	int use, mon;
	char c;
	
		printf("��뷮 �Է�:");
		scanf("%d", &use);
		if (use <= 20)
			mon = 1800;
		else if (use > 20 && 41 > use)
			mon = 1800 + 125 * (use - 20);
		else if (use >= 41 && 80 >= use)
			mon = 1800 + 125 * 20 + 165 * (use - 40);
		else if (use >= 81 && 100 >= use)
			mon = 1800 + 125 * 20 + 165 * 40 + 185 * (use - 80);
		else
			mon = mon = 1800 + 125 * 20 + 165 * 40 + 185 * 20 + 205 * (use - 100);
		printf("��뷮:%d, ���:%d\n", use, mon);
		for (;;)
		{
			printf("����Ͻðڽ��ϱ�?(y/n) :");
			scanf(" %c", &c);
			if (c == 89||c==121)
			{
				printf("��뷮 �Է�:");
				scanf("%d", &use);
				if (use <= 20)
					mon = 1800;
				else if (use > 20 && 41 > use)
					mon = 1800 + 125 * (use - 20);
				else if (use >= 41 && 80 >= use)
					mon = 1800 + 125 * 20 + 165 * (use - 40);
				else if (use >= 81 && 100 >= use)
					mon = 1800 + 125 * 20 + 165 * 40 + 185 * (use - 80);
				else
					mon = mon = 1800 + 125 * 20 + 165 * 40 + 185 * 20 + 205 * (use - 100);
				printf("��뷮:%d, ���:%d\n", use, mon);
			
			
			}
			else if (c ==78||c==110)
			{
				break;
			}
		}

	return 0;
}
