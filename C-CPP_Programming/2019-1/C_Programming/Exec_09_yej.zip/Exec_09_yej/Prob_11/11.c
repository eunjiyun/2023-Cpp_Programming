
#include <stdio.h>

int main()
{
	int A, B,a,b,c;
	
	
	for (A=0;A<10;A++)
	{
		for (B = 0; B< 10; B++)
		{
			a = 100 * A + 10 * A + B;
			b = 10 * B + B;
			c = 100 * B + 10 * A + A;
			if (a + b == c)
			{
				printf("AAB: %d, BB: %d, BAA: %d\n", a, b, c);
			}
		}
	}
	return 0;
}