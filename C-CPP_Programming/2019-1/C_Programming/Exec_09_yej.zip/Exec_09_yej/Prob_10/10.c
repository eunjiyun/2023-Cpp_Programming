#include <stdio.h>

int main()
{
	int i,sum,gs;
	gs = 0;
	sum = 0;
	for (i = 1; i <= 1000; i++)
	{
		if (i % 4 == 1 && i % 6 == 1)
		{
			gs++;
			
			printf("%d ", i);
			if (gs % 10 == 0)
				printf("\n");
			sum = sum + i;
		}
	}
	printf("\n �� %d���� �� %d", gs, sum);
}