#include <stdio.h>

int main()
{
	int t, adu, sec, fir, bab, sum, n, i, j,a,b,c,d;
	adu = 1;
	sec = 0;
	fir = 0;
	bab = 1;

	printf("����ð�   �������䳢��  �δ��䳢��  �Ѵ޵��䳢�� �Ʊ��䳢�� ���䳢��\n");

	for (t = 0; t <= 60; t++)
	{

		n = t / 10;
		if (n != 0)
			n = 1;


		sum = adu + sec + fir + bab;
		for (i = 0; i < 7 - n; i++)
			printf(" ");
		printf("%d", t);
		n = adu / 10;
		if (adu < 0)
		{
			if (n > -100000000)
				n = 9;
			else
				n = 10;
		}


		else if (n == 0)
			n = 0;
		else if (n < 10 && n>0)
			n = 1;
		else if (n < 100)
			n = 2;
		else if (n < 1000)
			n = 3;
		else if (n < 10000)
			n = 4;
		else if (n < 100000)
			n = 5;
		else if (n < 1000000)
			n = 6;
		else if (n < 10000000)
			n = 7;
		else if (n < 100000000)
			n = 8;
		else if (n < 1000000000)
			n = 9;

		for (j = 0; j < 11 - n; j++)
			printf(" ");
		printf("%d", adu);
		n = sec / 10;
		if (sec < 0)
		{
			if (n > -100000000)
				n = 9;
			else
				n = 10;
		}


		else if (n == 0)
			n = 0;
		else if (n < 10 && n>0)
			n = 1;
		else if (n < 100)
			n = 2;
		else if (n < 1000)
			n = 3;
		else if (n < 10000)
			n = 4;
		else if (n < 100000)
			n = 5;
		else if (n < 1000000)
			n = 6;
		else if (n < 10000000)
			n = 7;
		else if (n < 100000000)
			n = 8;
		else if (n < 1000000000)
			n = 9;
		for (a = 0; a < 11 - n; a++)
			printf(" ");
		printf("%d", sec);
		n = fir / 10;

		if (fir < 0)
		{
			if (n > -100000000)
				n = 9;
			else
				n = 10;
		}


		else if (n == 0)
			n = 0;
		else if (n < 10)
			n = 1;
		else if (n < 100)
			n = 2;
		else if (n < 1000)
			n = 3;
		else if (n < 10000)
			n = 4;
		else if (n < 100000)
			n = 5;
		else if (n < 1000000)
			n = 6;
		else if (n < 10000000)
			n = 7;
		else if (n < 100000000)
			n = 8;
		else if (n < 1000000000)
			n = 9;
		for (b = 0; b < 11 - n; b++)
			printf(" ");
		printf("%d", fir);
		n = bab / 10;

		if (bab < 0)
		{
			if (n > -100000000)
				n = 9;
			else
				n = 10;
		}


		else if (n == 0)
			n = 0;
		else if (n < 10)
			n = 1;
		else if (n < 100)
			n = 2;
		else if (n < 1000)
			n = 3;
		else if (n < 10000)
			n = 4;
		else if (n < 100000)
			n = 5;
		else if (n < 1000000)
			n = 6;
		else if (n < 10000000)
			n = 7;
		else if (n < 100000000)
			n = 8;
		else if (n < 1000000000)
			n = 9;
		for (c = 0; c < 11 - n; c++)
			printf(" ");
		printf("%d", bab);
		n = sum / 10;

		if (sum < 0)
		{
			if (n > -100000000)
				n = 9;
			else
				n = 10;
		}


		else if (n == 0)
			n = 0;
		else if (n < 10)
			n = 1;
		else if (n < 100)
			n = 2;
		else if (n < 1000)
			n = 3;
		else if (n < 10000)
			n = 4;
		else if (n < 100000)
			n = 5;
		else if (n < 1000000)
			n = 6;
		else if (n < 10000000)
			n = 7;
		else if (n < 100000000)
			n = 8;
		else if (n < 1000000000)
			n = 9;
		for (d = 0; d < 11 - n; d++)
			printf(" ");
		printf("%d\n", sum);



		adu = adu + sec;
		sec = fir;
		fir = bab;
		bab = adu;
	}



	return 0;
}