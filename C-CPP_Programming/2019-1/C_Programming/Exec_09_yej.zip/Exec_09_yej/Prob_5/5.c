#include <stdio.h>

int main()
{
	int i, n;
	n = 0;
	for (i = 1; i <= 100; i++)
	{
		if (i % 3 == 0 || i % 5 == 0 || i % 2 == 0)
			continue;

		n++;




		if (n == 1)
			printf("  %d", i);

		else if (n % 10 == 1)
			printf(" %d", i);
		else if (i < 10)
			printf("   %d", i);
		else if (i < 100)
			printf("  %d", i);
		if (n % 10 == 0)
			printf("\n");


	}


	return 0;
}
