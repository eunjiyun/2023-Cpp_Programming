#include <stdio.h>

int main()
{
	int n,a;
	n = 0;
	for (a = 1; a <=8; a++)
	{
		if (n < 100)
		{
			n = 10 * a + a + 1;
			printf("%d\n", n);
		}
		
	}
	for (a = 1; a <= 7; a++)
	{
		if (n < 1000)
		{
			n = 100 * a + 10 * (a + 1) + a + 2;
			printf("%d\n", n);
		}
	}
	
	return 0;
}