#include <stdio.h>
int compute_week(int year, int month, int day);
int main()
{

	int year, month, day;

	printf("�� �� �� �Է�: ");
	scanf("%d %d %d", &year, &month, &day);
	
	if (month == 0 || month > 12)
	{
		printf("�߸��� ���Դϴ�.");

		return 0;
	}
	if (month == 1 || month == 3 || month == 5 || month == 7 || month == 8 || month == 10 || month == 12)
	{
		if (day == 0 || day > 31)
		{
			printf("�߸��� ���Դϴ�.");
			return 0;
		}
	}
	else if (month == 4 || month == 6 || month == 9 || month == 11)
	{
		if (day == 0 || day > 30)
		{
			printf("�߸��� ���Դϴ�.");
			return 0;
		}
	}
	if (year % 400 == 0 && month == 2 && (day == 0 || day > 29))
	{
		printf("�߸��� ���Դϴ�.");
		return 0;
	}
	else if (year % 400 != 0 && month == 2 && (day == 0 || day > 28))
	{
		printf("�߸��� ���Դϴ�.");
		return 0;
	}
	compute_week(year, month, day);
	return 0;
}
	int compute_week(int year, int month, int day)
	{
		int  i, sum, days;
		sum = 0;
		if (year >= 1900)
		{
			for (i = 1900; i <= year - 1; i++)
			{
				if (i % 400 == 0)
					days = 366;
				else
					days = 365;
				sum = sum + days;
			}

			if (year % 400 == 0)
			{
				for (i = 1; i <= month - 1; i++)
				{
					if (i == 1 || i == 3 || i == 5 || i == 7 || i == 8 || i == 10 || i == 12)
						sum = sum + 31;
					else if (i == 2)
						sum = sum + 29;
					else if (i == 4 || i == 6 || i == 9 || i == 11)
						sum = sum + 30;

				}
			}
			else
			{
				for (i = 1; i <= month - 1; i++)
				{
					if (i == 1 || i == 3 || i == 5 || i == 7 || i == 8 || i == 10 || i == 12)
						sum = sum + 31;
					else if (i == 2)
						sum = sum + 28;
					else if (i == 4 || i == 6 || i == 9 || i == 11)
						sum = sum + 30;

				}
			}
			sum = sum + day - 1;

			if (sum % 7 == 0)
				printf("������");
			if (sum % 7 == 1)
				printf("ȭ����");
			if (sum % 7 == 2)
				printf("������");
			if (sum % 7 == 3)
				printf("�����");
			if (sum % 7 == 4)
				printf("�ݿ���");
			if (sum % 7 == 5)
				printf("�����");
			if (sum % 7 == 6)
				printf("�Ͽ���");
		}
		else
		{
			for (i = 1899; i >=year+1; i--)
			{
				if (i % 400 == 0)
					days = 366;
				else
					days = 365;
				sum = sum + days;
			}
			if (year % 400 == 0)
			{
				for (i = 12; i >=month +1; i--)
				{
					if (i == 1 || i == 3 || i == 5 || i == 7 || i == 8 || i == 10 || i == 12)
						sum = sum + 31;
					else if (i == 2)
						sum = sum + 29;
					else if (i == 4 || i == 6 || i == 9 || i == 11)
						sum = sum + 30;

				}
			}
			else
			{
				for (i = 12; i >= month +1; i--)
				{
					if (i == 1 || i == 3 || i == 5 || i == 7 || i == 8 || i == 10 || i == 12)
						sum = sum + 31;
					else if (i == 2)
						sum = sum + 28;
					else if (i == 4 || i == 6 || i == 9 || i == 11)
						sum = sum + 30;

				}

			}
			
			if (year % 400 == 0 && month == 2)
				sum = sum + 29 - day;
			else if (year % 400 != 0 && month == 2)
				sum = sum + 28 - day;
			else if (month == 4 || month == 6 || month == 9 || month == 11)
				sum = sum + 30 - day;
			else
				sum = sum + 31 - day;
			

			if (sum % 7 == 0)
				printf("�Ͽ���");
			if (sum % 7 == 1)
				printf("�����");
			if (sum % 7 == 2)
				printf("�ݿ���");
			if (sum % 7 == 3)
				printf("�����");
			if (sum % 7 == 4)
				printf("������");
			if (sum % 7 == 5)
				printf("ȭ����");
			if (sum % 7 == 6)
				printf("������");
		}
	}
	