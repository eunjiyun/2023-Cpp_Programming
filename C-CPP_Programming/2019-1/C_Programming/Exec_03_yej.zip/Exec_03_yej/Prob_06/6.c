#include <stdio.h>
int main()
{
	int x, y, z;
	printf("�� ���� x y z�Է�:");
	scanf("%d %d %d", &x, &y, &z);
	printf("�ִ밪");
	(x < y) ? (y > z) ? printf("%d",y): printf("%d",z) : (x > z) ? printf("%d",x) : printf("%d",z);
	return 0;
}