#include <stdio.h>
#define COLS 3
#define ROWS 3
static num;
int check(char ck[COLS][ROWS]);
int main()
{
	char bingo[COLS][ROWS] =  {' '};


	int x, y, i;
		printf("---|---|---\n");
		printf(" %c |%c  |%c\n", bingo[0][0], bingo[0][1], bingo[0][2]);
		printf("---|---|---\n");
		printf(" %c |%c  |%c\n", bingo[1][0], bingo[1][1], bingo[1][2]);
		printf("---|---|---\n");
		printf(" %c |%c  |%c\n", bingo[2][0], bingo[2][1], bingo[2][2]);
		printf("---|---|---\n");
		printf("(x,y)��ǥ(����-1,-1)");
	for (i = 0; i < 9; i++)
	{
		

		
		scanf_s("%d %d", &x, &y);


		if (x == -1 && y == -1)
			break;


		
		else if (bingo[x][y] == 79 || bingo[x][y] == 88)
		{
			printf("�߸��� ��ġ�Դϴ�.\n");
			if (check(bingo) != 1)
			
			printf("(x,y)��ǥ(����-1,-1)");
			i--;
			continue;

		}
		else if (x >= 0 && x < 3 && y >= 0 && y < 3)
		{

			if (i % 2 == 0)
				bingo[x][y] = 88;
			else if (i % 2 == 1)
				bingo[x][y] = 79;
		}
		else
		{
			printf("�߸��� ��ġ�Դϴ�.\n");
			if (check(bingo) != 1)
			printf("(x,y)��ǥ(����-1,-1)");
			i--;
			continue;

		}
		printf("---|---|---\n");
		printf(" %c |%c  |%c\n", bingo[0][0], bingo[0][1], bingo[0][2]);
		printf("---|---|---\n");
		printf(" %c |%c  |%c\n", bingo[1][0], bingo[1][1], bingo[1][2]);
		printf("---|---|---\n");
		printf(" %c |%c  |%c\n", bingo[2][0], bingo[2][1], bingo[2][2]);
		printf("---|---|---\n");
		if (check(bingo) != 1)
		printf("(x,y)��ǥ(����-1,-1)");
		
		else 
			break;
		
	}
	return 0;
}
int check(char ck[COLS][ROWS])
{
	int C, R;
	for (C = 0; C < COLS; C++)
	{
		if (ck[C][0] == 79 && ck[C][1] == 79 && ck[C][2] == 79)
		{
			printf("player O ��");
			num = 1;
		}
		else if (ck[C][0] == 88 && ck[C][1] == 88 && ck[C][2] == 88)
		{
			printf("player X ��");
			num = 1;
		}
	}
	for (R = 0; R < ROWS; R++)
	{
		if (ck[0][R] == 79 && ck[1][R] == 79 && ck[2][R] == 79)
		{
			printf("player O ��");
			num = 1;
		}
		else if (ck[0][R] == 88 && ck[1][R] == 88 && ck[2][R] == 88)
		{
			printf("player X ��");
			num = 1;
		}
	}
	if (ck[0][0] == 79 && ck[1][1] == 79 && ck[2][2] == 79 || ck[0][2] == 79 && ck[1][1] == 79 && ck[2][0] == 79)
	{
		printf("player O ��");
		num = 1;
	}
	else if (ck[0][0] == 88 && ck[1][1] == 88 && ck[2][2] == 88 || ck[0][2] == 88 && ck[1][1] == 88 && ck[2][0] == 88)
	{
		printf("player X ��");
		num = 1;
	}
	if (num == 1)
		return 1;
}