#include <stdio.h>
#define COLS 3
#define ROWS 6
int main()
{
	
	int grade[COLS][ROWS] = { {41,43,45,42,44,39},{41,43,45,42,44,39} ,{41,43,45,42,44,39} };
	int sum, sum1, sum2, sum3,sum11,sum22,sum33,sum44,sum55,sum66,i;
	sum1 = 0;
	sum2 = 0;
	sum3 = 0;
	sum11 = 0;
	sum22 = 0;
	sum33 = 0;
	sum44 = 0;
	sum55 = 0;
	sum66 = 0;
	printf("�г�   1��   2��   3��   4��   5��   6��   �հ�\n");
	for (i = 0; i < ROWS; i++)
	{
		sum1 = sum1 + grade[0][i];
	}
	for (i = 0; i < ROWS; i++)
	{
		sum2 = sum2 + grade[1][i];
	}
	for (i = 0; i < ROWS; i++)
	{
		sum3 = sum3 + grade[2][i];
	}
	for (i = 0; i < COLS; i++)
	{
		sum11 = sum11 + grade[i][0];
	}
	for (i = 0; i < COLS; i++)
	{
		sum22 = sum22 + grade[i][1];
	}
	for (i = 0; i < COLS; i++)
	{
		sum33 = sum33 + grade[i][2];
	}
	for (i = 0; i < COLS; i++)
	{
		sum44 = sum44 + grade[i][3];
	}
	for (i = 0; i < COLS; i++)
	{
		sum55 = sum55 + grade[i][4];
	}
	for (i = 0; i < COLS; i++)
	{
		sum66 = sum66 + grade[i][5];
	}
	sum = sum1 + sum2 + sum3;
	printf("1�г�   41    43    45    42    44    39 |  %d\n",sum1);
	printf("2�г�   41    43    45    42    44    39 |  %d\n",sum2);
	printf("3�г�   41    43    45    42    44    39 |  %d\n",sum3);
	printf("-----------------------------------------------------\n");
	printf("�հ�%6d %5d %5d %5d %5d %5d | %4d", sum11, sum22, sum33, sum44, sum55, sum66, sum);
	return 0;
}