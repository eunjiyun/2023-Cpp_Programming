#include <stdio.h>
#define COLS 26
#define ROWS 26
int main()
{
	
	char alphabet_show_table[ROWS][COLS];
	alphabet_show_table[0][0] = 65;
	int i, j;
		printf("Alphabet show table\n");
		
			for (i = 0; i < ROWS; i++)
			{
				
				for (j = 0; j < COLS; j++)
				{
					if (j == 25)
						break;
					else
						alphabet_show_table[i][j + 1] = alphabet_show_table[i][j] + 1;
				}
					
						for (j = COLS - i; j < COLS; j++)
							alphabet_show_table[i][j] = alphabet_show_table[i][j] - 26;
					
			}

			for (j = 0; j < COLS; j++)
			{
				for (i = 0; i < ROWS; i++)
				{
					if (i == 25)
						break;
					else
					alphabet_show_table[i + 1][j] = alphabet_show_table[i][j] + 1;
				}
				
					for (i = ROWS - j; i < ROWS; i++)
						alphabet_show_table[i][j] = alphabet_show_table[i][j] - 26;
				

			}

		
				
		for (i = 0; i < ROWS; i++)
		{
			for (j = 0; j < COLS; j++)
				printf("%c", alphabet_show_table[i][j]);
			printf("\n");
		}
	return 0;
}