#include <stdio.h>
#define COLS 11
int main()
{
	int n,i;
	int rage[COLS] = { 0 };

	for (;;)
	{
		printf("0~100������ ������ �Է�(����: -1)");
		scanf("%d", &n);
		if (n >= 0 && n <= 9)
			rage[0]++;
		else if (n >= 10 && n <= 19)
			rage[1]++;
		else if (n >= 20 && n <= 29)
			rage[2]++;
		else if (n >= 30 && n <= 39)
			rage[3]++;
		else if (n >= 40 && n <= 49)
			rage[4]++;
		else if (n >= 50 && n <= 59)
			rage[5]++;
		else if (n >= 60 && n <= 69)
			rage[6]++;
		else if (n >= 70 && n <= 79)
			rage[7]++;
		else if (n >= 80 && n <= 89)
			rage[8]++;
		else if (n >= 90 && n <= 99)
			rage[9]++;
		else if (n >= 100 && n <= 109)
			rage[10]++;
		
		if (n == -1)
			break;
	}
	printf("0~9 ���� : %d :", rage[0]);
	for (i = 0; i < rage[0]; i++)
	{
		printf("*");
	}
	printf("\n");
	printf("10~19 ���� : %d :", rage[1]);
	for (i = 0; i < rage[1]; i++)
	{
		printf("*");
	}
	printf("\n");
	printf("20~29 ���� : %d :", rage[2]);
	for (i = 0; i < rage[2]; i++)
	{
		printf("*");
	}
	printf("\n");
	printf("30~39 ���� : %d :", rage[3]);
	for (i = 0; i < rage[3]; i++)
	{
		printf("*");
	}
	printf("\n");
	printf("40~49 ���� : %d :", rage[4]);
	for (i = 0; i < rage[4]; i++)
	{
		printf("*");
	}
	printf("\n");
	printf("50~59 ���� : %d :", rage[5]);
	for (i = 0; i < rage[5]; i++)
	{
		printf("*");
	}
	printf("\n");
	printf("60~69 ���� : %d :", rage[6]);
	for (i = 0; i < rage[6]; i++)
	{
		printf("*");
	}
	printf("\n");
	printf("70~79 ���� : %d :", rage[7]);
	for (i = 0; i < rage[7]; i++)
	{
		printf("*");
	}
	printf("\n");
	printf("80~89 ���� : %d :", rage[8]);
	for (i = 0; i < rage[8]; i++)
	{
		printf("*");
	}
	printf("\n");
	printf("90~99 ���� : %d :", rage[9]);
	for (i = 0; i < rage[9]; i++)
	{
		printf("*");
	}
	printf("\n");
	printf("100~109 ���� : %d :", rage[10]);
	for (i = 0; i < rage[10]; i++)
	{
		printf("*");
	}
	printf("\n");
	return 0;
}