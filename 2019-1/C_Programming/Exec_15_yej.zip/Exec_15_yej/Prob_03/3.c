#include <stdio.h>
void array_copy(int *a, int *b, int size);
void array_print(int *a, int size);
#define size1 10
int main(void)
{
	int i;

     	
		int j = 1;
		
	int *pj= &j; 
	int pk[size1] = { NULL };
	
	for (i = 0; i < size1; i++)
	{
		*(pj+4*( i + 1)) = *(pj+ 4*i )+ 1;
	}
	printf("������ A �迭:");
	for (i = 0; i < size1; i++)
	{
		printf(" %d", (*pj)+i); 
	}
	printf("\n������ B �迭:");
	for (i = 0; i < size1; i++)
	{
		printf(" %d", pk[i]);
	}
	
	
	
	array_copy(pj, pk, size1);
	array_print(pk, size1);
	return 0;

}
void array_copy(int *a, int *b, int size)
{
	int i;
	for (i = 0; i < size; i++)
	{
		*(b + i) = *(a + i);
	}
}
void array_print(int *a, int size)
{
	int i;
	
	printf("\n\n������ A �迭:");
	for (i = 0; i < size; i++)
	{
		printf(" %d", (*a) + i);
	}
	printf("\n������ B �迭:");
	for (i = 0; i < size; i++)
	{
		printf(" %d", (*a) + i);
	}
}