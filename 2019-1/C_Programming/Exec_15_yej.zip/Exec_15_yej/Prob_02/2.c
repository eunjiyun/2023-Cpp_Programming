#include <stdio.h>
int main(void)
{
	int n = 0x12345678;
	unsigned char *p = (unsigned char*)&n;

	printf("����Ʈ���� : %x %x %x %x \n",
		*p, *(p + 1), *(p + 2), *(p + 3));
	return 0;
}c