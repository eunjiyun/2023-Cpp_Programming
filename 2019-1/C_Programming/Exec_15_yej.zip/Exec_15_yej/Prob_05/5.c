#include <stdio.h>
#define size 10
void merge(int *A, int sizeA, int *B, int sizeB, int *C);
void sort(int *A, int *B);
int main()
{
	int i;
	int a[31] = { 1,4,5,28,5,9,10,20,44,50 };
	int b[31] = { 3,45,7,23,37,15,33,47,18,49 };
	int d[31] = { 3,45,7,23,37,15,33,47,18,49 };
	int c[70] = { 0 };
	printf("���� �� A �迭\n");
	for (i = 0; i < size; i++)
	{

		printf("%d ", *(a + i));
	}
	
	
	sort(a,b);
	printf("\n���� �� A �迭\n");
	for (i = 0; i < size; i++)
		printf("%d ", *(a + i));
printf("\n���� �� B �迭\n");
	for (i = 0; i < size; i++)
	{

		printf("%d ", *(d + i));
	}
	printf("\n���� �� B �迭\n");
	for (i = 0; i < size; i++)
		printf("%d ", *(b + i));
	merge(a, size, b, size, c);
	return 0;
}
void sort(int *A, int *B)
{
	int i, j,least,temp;
	for (i = 0; i < size - 1; i++)
	{
		least = i;
		for (j = i + 1; j < size; j++)
		{
			if (A[least] > A[j])
				least = j;
		}
		temp = A[i];
		A[i] = A[least];
		A[least] = temp;

	}
		
	
	for(i=0;i<size-1;i++)
	{
		least = i;
		for (j = i + 1; j < size; j++)
		{
			if (B[least] > B[j])
				least = j;
		}
				temp = B[i];
				B[i] = B[least];
				B[least] = temp;
				
			
		
	}
	
	
	
}
void merge(int *A, int sizeA, int *B, int sizeB, int *C)
{
	printf("\nA �迭�� B �迭 ���� �� C �迭\n");
	int i,j;
	
	

	for (i = 0; i < 2 * size; i++)
	{
		if (A[i] <= B[i])
		{
			C[i] = A[i];
			for (j = size + i; j >= i-1 ; j--)
				B[j + 1] = B[j];
		}
		else if (A[i] ==0)
			C[i] = B[i];
		else if (B[i] ==0)
			C[i] = A[i];
		else
		{
			C[i] = B[i];
			for (j = size + i; j >= i-1 ; j--)
				A[j + 1] = A[j];
		}





	}for (i = 0; i < size*2; i++)
	{
		printf("%d ", C[i]);
	}
	

}