#include <stdio.h>
// �迭�� ������ ����
int main(void)
{
	int ptr[] = { 1, 2, 3, 4, 5 };
	int	*ptr1, *ptr2;

	ptr1 = ptr;
	ptr2 = &ptr[1];
	printf("ptr1=%#x, *ptr1=%d, &ptr1 = %#x \n", ptr1, *ptr1, &ptr1);
	ptr1++;
	*ptr1++;
	printf("ptr1=%#x, *ptr1=%d, &ptr1 = %#x \n", ptr1, *ptr1, &ptr1);
	printf("ptr2=%#x, *ptr2=%d, &ptr2 = %#x \n", ptr2, *ptr2, &ptr2);
	ptr2++;
	*++ptr2;
	printf("ptr2=%#x, *ptr2=%d, &ptr2 = %#x \n", ptr2, *ptr2, &ptr2);
	ptr2--;
	*--ptr2;
	printf("ptr2=%#x, *ptr2=%d, &ptr2 = %#x \n", ptr2, *ptr2, &ptr2);

	return 0;
}