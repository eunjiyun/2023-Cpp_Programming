#include <stdio.h>
void get_gcd_lcm(int x, int y, int *gcd, int *lcm);
int main(void)
{
	int num1, num2;
	int l = 0;
	int g = 0;
	printf("�ΰ��� ������ �Է��Ͻÿ�:");
	scanf("%d %d", &num1, &num2);
	get_gcd_lcm(num1, num2,&g,&l);
	printf("�ּҰ������ %d�Դϴ�\n", l);
	printf("�ִ������� %d�Դϴ�", g);
	return 0;
}
void get_gcd_lcm(int x, int y, int *gcd, int *lcm)
{
	int i,a,b,j,x2,y2;
	a = 1;
	b = 1;
	x2 = x;
	y2 = y;
	if (x >= y)
	{
		for (j = 1; j < y; j++)
		{
			for (i = 2; i <= y; i++)
			{
				if (x%i == 0 && y%i == 0)
				{
					x = x / i;
					y = y / i;
					a = a * i;
				}
				else
				{
					
					continue;
				}
				
			}
			
		}
		a = a * x*y;
	}
	else
		{
	
		for (j = 1; j < x; j++)
		{
			for (i = 2; i <= x; i++)
			{
				if (x%i == 0 && y%i == 0)
				{
					x = x / i;
					y = y / i;
					a = a * i;
				}
				else
				{

					continue;
				}

			}
			
		}
	a = a * x*y;
	    }

	if (x2 >= y2)
	{
		for (j = 1; j < y2; j++)
		{
			for (i = 2; i <= y2; i++)
			{
				if (x2%i == 0 && y2%i == 0)
				{
					x2 = x2 / i;
					y2 = y2 / i;
					b = b * i;
				}
				else
				{

					continue;
				}
			}
		}
	}
	else
	{

		for (j = 1; j < x2; j++)
		{
			for (i = 2; i <= x2; i++)
			{
				if (x2%i == 0 && y2%i == 0)
				{
					x2 = x2 / i;
					y2 = y2 / i;
					b = b * i;
				}
				else
				{

					continue;
				}
			}
		}
	}
	*lcm = a;
	*gcd = b;

}

