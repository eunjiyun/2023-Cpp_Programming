#include <stdio.h>
int main()
{
	int dis,mon;
	
	printf("���� �Ÿ��� �Է��ϼ���. :");
	scanf("%d", &dis);
	printf("���: ");
	if (dis <= 1000)
		printf("1100");
	else if (dis > 1000 && dis <= 2000)
	{
		
		
		mon = (dis - 1000) / 100 * 20 + 1100;
			
			printf("%d", mon);
	}


	
	else if (dis > 2000)
	{
	
		mon = (dis - 2000) / 100 * 40 + 1300;
		printf("%d", mon);
	}



	return 0;
}