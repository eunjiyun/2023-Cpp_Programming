#include <stdio.h>
int bp(int x,int y,int z);
int mj(int x, int y, int z);


int main()
{
	int a, b, c;
	scanf("%d %d %d", &a, &b, &c);
	int bp(a, b, c);
	int mj(a, b, c);
	printf("����:%d ǥ����:%d", bp(a, b, c),  mj(a, b, c));
	return 0;
}
int bp(int x, int y, int z)
{
	int  BP;
	BP = x * y*z;
	return BP;
	
}
int mj(int x, int y, int z)
{
	int  MJ;
	
	MJ = 2 * (x*y + x * z + y * z);
	return MJ;
}
