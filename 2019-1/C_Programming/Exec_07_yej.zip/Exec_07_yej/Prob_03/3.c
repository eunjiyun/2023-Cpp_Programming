#include <stdio.h>
int prime(int x);
int main()
{

	int n, i;
	printf("n�� �� �Է�: ");
	scanf("%d", &n);
	printf("1���� %d������ �Ҽ�\n", n);
	for (i = 1; i <= n; i++)
	{
	
		if (prime(i)==1)
			printf("%d ", i);
		
	}
	return 0;
}
int prime(int x)
{
	int i,yg;
	yg = 0;
	
	for (i = 1; i <= x; i++)
	{
		if (x%i == 0)
			yg++;
	}
	if(yg==2)
			return 1;
		else
			return 0;
}
