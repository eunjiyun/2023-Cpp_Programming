#include <LinkedList.h>
struct node
{
	struct node *next;
	int data;

};
void addNode(node **head, int id, char name[]);
node* searchNode(node *p, int id);
node* deleteNode(node *p, int id);
void printNode(node * p);
void freeAllNode(node *p);
int fibo(int x);
double start, end, start_1, end_1;
int main()
{
	int n,fn,i;
	

	printf("���ϰ��� �ϴ� �� �Է� :");
	scanf("%d", &n);
	int *f = (int *)malloc(sizeof(int)*(n));
	start = clock();
	fn = fibo(n-1);
	end = clock();
	printf("����� ���: %d���� �� = %d, �ҿ�ð�: %lf\n", n, fn, end - start) ;
	start_1 = clock();
	*f = 1;
		*(f + 1) = 2;
	for (i = 0; i < n - 2; i++)
	{
		
		*(f + 2) = *f + *(f + 1);
		*f = *(f + 1);
		*(f + 1) = *(f + 2);
	}
	end_1 = clock();
	printf("�迭 �ݺ� ���: %d���� �� = %d, �ҿ�ð�: %lf", n, *(f + 2), end_1 - start_1);
	return 0;
}
int fibo(int x)
{
	
	if (x<=1)
		return x + 1;
	else
		return fibo(x - 1) + fibo(x - 2);

}