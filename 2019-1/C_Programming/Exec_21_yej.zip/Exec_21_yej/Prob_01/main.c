#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
extern void addNode(node **head, int id, char name[]);
 extern node* searchNode(node *p, int id);
extern node* deleteNode(node *p, int id);
extern void printNode(node * p);
extern void freeAllNode(node *p);


struct node
{
	struct node *next;
	int data;
	
};
struct Student {
	char name[10];
	int id;
	struct Student*p1;
};


int main()
{
	int n;
	struct Student *p1;
	struct Student *p1 = malloc(sizeof(struct Student));   
	// ����ü ������ ����, �޸� �Ҵ�
	printf("����:");
	scanf("%d", &n);
	switch (n)
	{
	case 1:
		addNode(node **head, int id, char name[]);
		break;
	case 2:
		node* searchNode(node *p, int id);
		printNode(node * p);
		break;
	case 3:
		node* deleteNode(node *p, int id);
		freeAllNode(node *p);
		break;
	case 4:
		printNode(node * p);
		break;
	case 5:
		node* deleteNode(node *p, int id);
		break;
	case 6:
		return 0;
	}
	// ȭ��ǥ �����ڷ� ����ü ����� �����Ͽ� �� �Ҵ�
	strcpy(p1->name, "ȫ�浿");
	p1->age = 30;
	strcpy(p1->address, "����� ��걸 �ѳ���");


	/*struct NODE *head = malloc(sizeof(struct NODE));

	struct NODE *node1 = malloc(sizeof(struct NODE));
	head->next = node1;
	node1->data = 10;*/
	return 0;
}